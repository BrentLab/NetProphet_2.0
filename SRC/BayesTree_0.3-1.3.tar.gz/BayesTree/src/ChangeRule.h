void CatFindBots(Node *curr,int VarI,int cat,NodeP *botvec,int *fcount);
void FindGoodOrdRules(Node *n,int VarI, int &l, int &u);
void OrdFindMinMax(Node *n,int VarI, int *min, int *max);
void FindGoodCatRules(Node *n,int VarI, int *RuleInd,int &firstone);
int NoZero(int n,int *v);
int FirstOne(int n,int *v);
double ChangeRule(Node *top,int *Done);

