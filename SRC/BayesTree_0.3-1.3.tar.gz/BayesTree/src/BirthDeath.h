double PBirth(Node *top,Node **n,double *prob);
double DrNogNode(Node *top,Node **n);

int DrNode(Node *top,Node **node, double *nprob);
double PrBotNode(Node *top,Node *node);
double NodeProb(Node *n);
void KillChildren(Node *nog);
double BirthDeath(Node *x,int *BD,int *Done);


