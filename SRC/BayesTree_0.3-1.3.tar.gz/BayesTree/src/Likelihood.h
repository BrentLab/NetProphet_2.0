double LogLNode(Node *n);
double LogLT(Node *branch, Node *top);

