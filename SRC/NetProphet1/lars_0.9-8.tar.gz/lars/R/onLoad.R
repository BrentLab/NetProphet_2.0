.onLoad=function(libname,pkgname){
  cat("Loaded lars",utils::installed.packages()["lars","Version"],"\n")
}
